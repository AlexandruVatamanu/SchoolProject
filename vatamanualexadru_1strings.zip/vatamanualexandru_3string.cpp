#include <iostream>
#include <string.h>
using namespace std;

int task3()
{
    string c;
    cout<<"Introduce-ti un sir de caractere: ";
    cin>>c;
    for(int i=0;i<c.size();i++)
    {
        if(isupper(c[i]))
            {
                c[i]=tolower(c[i]);
            }
    }
    cout<<"Sirul transformat este: "<<c<<endl;
}





int main()
{
    task3();
}
